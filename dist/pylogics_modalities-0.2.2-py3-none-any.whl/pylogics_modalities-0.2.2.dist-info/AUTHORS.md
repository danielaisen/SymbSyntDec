# Credits

## Maintainers

- [Marco Favorito](https://github.com/marcofavorito)

## Contributors

- [Francesco Fuggitti](https://github.com/francescofuggitti)
- [Roberto Cipollone](https://github.com/cipollone)


[Do you want to be a contributor](./contributing.md)? 
